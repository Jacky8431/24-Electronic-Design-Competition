#ifndef __ENCODER_H
#define __ENCODER_H

extern volatile float  Encoder_speed1 ;
extern volatile float  Encoder_speed2 ;
#include "board.h"
void Encoder_Init1();
void Encoder_Init2();
void GROUP1_IRQHandler(void);
void  Get_Encoder_speed1();
void  Get_Encoder_speed2();
#endif 
