#include "OPENMV4.h"
#include "stdio.h"
#include "oled.h"
#include "PID.h"


char OPENMV_BUFF[OPENMV_LEN_MAX];
unsigned char OPENMV_FLAG = 0;
unsigned char OPENMV_LEN = 0;
int data1;
int b;
int a;
volatile uint8_t com_data;

void OPENMV_Send_Bit(unsigned char ch)
{
    
      while( DL_UART_isBusy(UART_1_INST) == true );
      
      DL_UART_Main_transmitData(UART_1_INST, ch);
}


void OPENMV_send_String(unsigned char *str)
{
      while( str && *str ) 
      {
            OPENMV_Send_Bit(*str++);
      }
}


void Clear_OPENMV_BUFF(void)
{
      OPENMV_LEN = 0;
      OPENMV_FLAG = 0;
}


void OPENMV_Init(void)
{
       //清除串口中断标志
        //NVIC_ClearPendingIRQ(UART_2_INST_INT_IRQN);
        NVIC_EnableIRQ(UART_1_INST_INT_IRQN);

    
}






void Receive_OPENMV_Data(void)
{
      if( OPENMV_FLAG == 1 )
      {
            
//           printf("%s\r\n",OPENMV_BUFF);
				if(sscanf(OPENMV_BUFF,"%d",&data1) == 1)
				{
					if(data1 >=0)
					{
					  b = data1 ;
		
						OLED_Clear();
						OLED_ShowNum(0,0,(uint32_t)b,3,8,1);
						OLED_Refresh();
					}
					else
					{
						 a= -data1;
				
				
						OLED_Clear();
						OLED_ShowString(0,0,(uint8_t *)"-",8,1);
						OLED_ShowNum(6,0,(uint32_t)a,3,8,1);
						OLED_Refresh();
					}
					
				}
				
            Clear_OPENMV_BUFF();
      }

}




void UART_1_INST_IRQHandler(void)
{
	
	
		static uint8_t RxState =0;
		switch( DL_UART_getPendingInterrupt(UART_1_INST) )
		{
			case DL_UART_IIDX_RX:

             
              if (OPENMV_LEN < OPENMV_LEN_MAX - 1) 
              {
                    com_data  = DL_UART_Main_receiveData(UART_1_INST); 
										if(RxState==0&com_data == 0x2C)
										{
											RxState =1;
										}
										else if(RxState == 1 & com_data == 0x12)
										{
											RxState =2;
										}
										else if(RxState ==2)
										{
											if(com_data == 0x5b)
											{
												RxState = 3;
											}
											else 
											{
												OPENMV_BUFF[OPENMV_LEN++] = com_data;
											}
										}
										else if(RxState ==3)
										{
											RxState =0;
											OPENMV_BUFF[OPENMV_LEN] = '\0';  
											OPENMV_FLAG = 1;  
										}
              }
              else
              {
                    uint8_t temp = DL_UART_Main_receiveData(UART_1_INST); 
              }

        
              break;

			default:
						  break;
		}
}