#ifndef __OPENMV4_H
#define __OPENMV4_H

#include "board.h"
#include "string.h"


#define  OPENMV_LEN_MAX  200
extern int data1;
extern int a ;
extern int b;
extern   char OPENMV_BUFF[OPENMV_LEN_MAX];
extern unsigned char OPENMV_FLAG ;
extern unsigned char OPENMV_LEN ;
void OPENMV_Init(void);
void UART_2_INST_IRQHandler(void);
void Receive_OPENMV_Data(void);
void Clear_OPENMV_BUFF(void);
void OPENMV_send_String(unsigned char *str);
void OPENMV_Send_Bit(unsigned char ch);
#endif
