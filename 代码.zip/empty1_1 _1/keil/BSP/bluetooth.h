#ifndef __BLUETOOTH_H
#define __BLUETOOTH_H

#include "board.h"
#include "string.h"


#define  BLERX_LEN_MAX  200

extern unsigned char BLERX_BUFF[BLERX_LEN_MAX];
extern unsigned char BLERX_FLAG ;
extern unsigned char BLERX_LEN ;
void Bluetooth_Init(void);
void UART_2_INST_IRQHandler(void);
void Receive_Bluetooth_Data(void);
void Clear_BLERX_BUFF(void);
void BLE_send_String(unsigned char *str);
void BLE_Send_Bit(unsigned char ch);
#endif
