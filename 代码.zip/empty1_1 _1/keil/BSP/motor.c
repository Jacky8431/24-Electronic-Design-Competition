#include "motor.h"
#include "Encoder.h"
#include "my_timer.h"
float out_Pwm;
float Target = 60.0;



void Motor_SetPWM0(uint32_t speed)
{
	 DL_TimerG_setCaptureCompareValue(PWM0_INST,speed,GPIO_PWM0_C0_IDX);
}
 
void Motor_Go0()
{
	Motor_SetPWM0(out_Pwm);
	AIN1_OUT(0);
	AIN2_OUT(1);
}

void Motor_Back0()
{
	Motor_SetPWM0(out_Pwm);
	AIN1_OUT(1);
	AIN2_OUT(0);
}



void Motor_SetPWM1(uint32_t speed)
{
	 DL_TimerG_setCaptureCompareValue(PWM1_INST,speed,GPIO_PWM1_C0_IDX);
}
 
void Motor_Go1()
{
	Motor_SetPWM1(out_Pwm);
	BIN1_OUT(0);
	BIN2_OUT(1);
}

void Motor_Back1()
{
	Motor_SetPWM1(out_Pwm);
	BIN1_OUT(1);
	BIN2_OUT(0);
}



void zuozhuan(int times)
{
	AIN1_OUT(0);
	AIN2_OUT(0);
	BIN1_OUT(1);
	BIN2_OUT(0);
	Motor_SetPWM0(0);
	Motor_SetPWM1(200);
	delay_ms(times);
	
}