#ifndef _MOTOR_H
#define _MOTOR_H

#include "board.h"


#define AIN1_OUT(X)  ( (X) ? (DL_GPIO_setPins(GPIO0_PORT,GPIO0_AIN1_PIN)) : (DL_GPIO_clearPins(GPIO0_PORT,GPIO0_AIN1_PIN)) )
#define AIN2_OUT(X)  ( (X) ? (DL_GPIO_setPins(GPIO0_PORT,GPIO0_AIN2_PIN)) : (DL_GPIO_clearPins(GPIO0_PORT,GPIO0_AIN2_PIN)) )
#define BIN1_OUT(X)  ( (X) ? (DL_GPIO_setPins(GPIO1_PORT,GPIO1_BIN1_PIN)) : (DL_GPIO_clearPins(GPIO1_PORT,GPIO1_BIN1_PIN)) )
#define BIN2_OUT(X)  ( (X) ? (DL_GPIO_setPins(GPIO1_PORT,GPIO1_BIN2_PIN)) : (DL_GPIO_clearPins(GPIO1_PORT,GPIO1_BIN2_PIN)) )
extern float out_Pwm;
void Motor_SetPWM0(uint32_t speed);
void Motor_Go0();
void Motor_Back0();

void Motor_SetPWM1(uint32_t speed);
void Motor_Go1();
void Motor_Back1();
void zuozhuan(int times);
float Speed_PID(float Encoder_speed,float Target);
#endif  