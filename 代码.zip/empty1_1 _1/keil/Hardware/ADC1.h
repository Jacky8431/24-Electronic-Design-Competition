#ifndef __ADC1_H
#define __ADC1_H
#include "ti_msp_dl_config.h"
extern volatile bool gCheckADC;        //ADC采集成功标志位
extern volatile uint16_t ADC_VALUE[20];
unsigned int adc_getValue(void);
void ADC_VOLTAGE_INST_IRQHandler(void);
unsigned int adc_getValueDMA(unsigned int number);
void ADC_DMA_Init(void);
#endif