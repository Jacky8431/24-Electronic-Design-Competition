#include "Key.h"

//volatile unsigned int delay_times = 0;



//uint8_t Key_GetNum(void)
//{
//	uint8_t Key_Num = 0;
//	if(DL_GPIO_readPins(Key_PORT,Key_PA23_PIN) == 0)
//	{
//		delay_ms(20);
//		if(DL_GPIO_readPins(Key_PORT,Key_PA23_PIN) == 0)
//		{
//			if(Key_Num == 0)
//				Key_Num = 1;
//			else if(Key_Num == 1)
//				Key_Num = 2;
//			else if(Key_Num == 2)
//				Key_Num = 3;
//			else if(Key_Num == 3)
//				Key_Num = 4;
//			else
//				Key_Num = 0;						
//			while(!DL_GPIO_readPins(Key_PORT,Key_PA23_PIN)) ;
//		}
//	}
//	return Key_Num;
//}


