#ifndef __KEY_H
#define __KEY_H

#include "board.h"

void SysTick_Handler(void);
uint8_t Key_GetNum(void);
#endif