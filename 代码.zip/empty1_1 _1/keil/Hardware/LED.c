#include "LED.h"

//暂时关闭GPIO_LED
//void LED_toggle()
//{
//	DL_GPIO_togglePins(LED1_PORT, LED1_PIN_14_PIN);
//}

//void LED_ON()
//{
//	DL_GPIO_setPins(LED1_PORT,LED1_PIN_14_PIN);
//}

//void LED_OFF()
//{
//	DL_GPIO_clearPins(LED1_PORT,LED1_PIN_14_PIN);
//}