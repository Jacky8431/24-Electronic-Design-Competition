#ifndef __LED_H
#define __LED_H

#include "ti_msp_dl_config.h"

void LED_toggle();
void LED_ON();
void LED_OFF();
#endif