#include "TCRT.h"


int ReadTCRT()
{
	int a =0;
	
  if(!DL_GPIO_readPins(GPIOA,TCRT1_OUT1_PIN))
	{
		a =1;
		
	}
	
	if(!DL_GPIO_readPins(GPIOA,TCRT1_OUT2_PIN))
	{
		a =2;
		
	}
	if(!DL_GPIO_readPins(GPIOA,TCRT1_OUT3_PIN))
	{
		a =3;
		
	}
	if(!DL_GPIO_readPins(GPIOA,TCRT1_OUT4_PIN))
	{
		a =4;
		
	}
	if(!DL_GPIO_readPins(GPIOB,TCRT2_OUT5_PIN))
	{
		a =5;
		
	}
	if(DL_GPIO_readPins(GPIOA,TCRT1_leftout_PIN)>0)
	{
		a = 6;
	}
	if(DL_GPIO_readPins(GPIOA,TCRT1_rightout_PIN)>0)
	{
		a = 7;
	}
	if(DL_GPIO_readPins(GPIOA,TCRT1_midleftout_PIN)>0)
	{
		a = 8;
	}
	if(DL_GPIO_readPins(GPIOA,TCRT1_midrightout_PIN)>0)
	{
		a = 9;
	}
		
	

	return  a;
	
}