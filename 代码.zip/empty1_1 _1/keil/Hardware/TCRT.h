#ifndef __TCRT_H
#define __TCRT_H
#include "board.h"




int ReadTCRT();

#endif