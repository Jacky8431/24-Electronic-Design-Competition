#ifndef __USART0_H_
#define __USART0_H_
#include "stdio.h"
#include "ti_msp_dl_config.h"
int fputc(int ch, FILE *stream);
void uart0_send_char(char ch);
void uart0_send_string(char* str);
#endif