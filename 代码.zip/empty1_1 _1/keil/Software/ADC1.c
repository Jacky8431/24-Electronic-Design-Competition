#include "ADC1.h"

volatile bool gCheckADC;        //ADC采集成功标志位
volatile uint16_t ADC_VALUE[20];
//读取ADC的数据
unsigned int adc_getValue(void)
{
        unsigned int gAdcResult = 0;

        //软件触发ADC开始转换
        DL_ADC12_startConversion(ADC_VOLTAGE_INST);
        //如果当前状态为正在转换中则等待转换结束
        while (false == gCheckADC) {
            __WFE();
        }
        //获取数据
        gAdcResult = DL_ADC12_getMemResult(ADC_VOLTAGE_INST, ADC_VOLTAGE_ADCMEM_ADC_CH0);

        //清除标志位
        gCheckADC = false;

        return gAdcResult;
}

//ADC中断服务函数
void ADC_VOLTAGE_INST_IRQHandler(void)
{
        //查询并清除ADC中断
        switch (DL_ADC12_getPendingInterrupt(ADC_VOLTAGE_INST))
        {
                        //检查是否完成数据采集
                        case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
                                        gCheckADC = true;//将标志位置1
                                        break;
                        default:
                                        break;
        }
}


//DMA数据搬运

void ADC_DMA_Init(void)
{
				//设置DMA搬运的起始地址
        DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &ADC0->ULLMEM.MEMRES[0]);
        //设置DMA搬运的目的地址
        DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &ADC_VALUE[0]);
        //开启DMA
        DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
        //开启ADC转换
        DL_ADC12_startConversion(ADC_VOLTAGE_INST);
}

//读取ADC的数据
unsigned int adc_getValueDMA(unsigned int number)
{
        unsigned int gAdcResult = 0;
        unsigned char i = 0;

        //采集多次累加
        for( i = 0; i < number; i++ )
        {
                gAdcResult += ADC_VALUE[i];
        }
        //均值滤波
        gAdcResult /= number;

        return gAdcResult;
}

//int main(void)
//{
//        unsigned int adc_value = 0;
//        unsigned int voltage_value = 0;

//        SYSCFG_DL_init();

//        //清除串口中断标志
//        NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);
//        //开启串口中断
//        NVIC_EnableIRQ(UART_0_INST_INT_IRQN);
//        //开启ADC中断
//        NVIC_EnableIRQ(ADC_VOLTAGE_INST_INT_IRQN);

//        printf("adc Demo start\r\n");
//        while (1)
//        {
//                //获取ADC数据
//                adc_value = adc_getValue();
//                printf("adc value:%d\r\n", adc_value);

//                //将ADC采集的数据换算为电压
//                voltage_value = (int)((adc_value/4095.0*3.3)*100);

//                printf("voltage value:%d.%d%d\r\n",
//                voltage_value/100,
//                voltage_value/10%10,
//                voltage_value%10 );

//                delay_ms(1000);
//        }
//}
