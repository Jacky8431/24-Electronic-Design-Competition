#include "my_timer.h"
#include "Encoder.h"
#include "PID.h"
#include "motor.h"
#include "OPENMV4.h"
#include "oled.h"
#include "TCRT.h"

volatile float Encoder_speed_1;
volatile float Encoder_speed_2;

volatile float Encoder_speed_3;
volatile float Encoder_speed_4;

volatile float real_speed1 ;
volatile float real_speed2 ;

volatile float Encoder_speed_bias1;
volatile float Encoder_speed_bias2;
volatile float Encoder_speed_bias3;

volatile float Encoder_speed_bias4;
volatile float Encoder_speed_bias5;
volatile float Encoder_speed_bias6;


//定义PID控制器结构体
PID_Controller suduPID1; //速度环PID控制器 
PID_Controller suduPID2; //速度环PID控制器 
PID_Controller  zhuanxiangPID1;
PID_Controller  zhuanxiangPID2;


//直线目标速度
#define Target 20.0f

//PID计算值
float speed1;
float speed2;
float speedyaw;
float zhuanwanyaw;



//PWM值
int PWM_speed1 ;
int PWM_speed2;
int PWM_zhuanxiangerr ;
int PWM_zhuanwan;

//获取6050转向误差
float data6050err;

float yaw1;
float yawreal;

//转向环误差输入值
float errin;

//方向
uint8_t speed_direction = 0;



//值
int getback1; //读取循迹模块引脚状态
int getback2;

int timesccl;

int abc;



//标志位
uint8_t flag1;
uint8_t flag2;
uint8_t timesflag;
int key_flag=1;
uint8_t changeflag;






//TIMER0初始化
void TIMER_0_Init()
{
	 //清除定时器中断标志
   NVIC_ClearPendingIRQ(TIMER_0_INST_INT_IRQN);
   //使能定时器中断
   NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
}


//定时器0的中断服务函数 已配置为100ms的周期
void TIMER_0_INST_IRQHandler(void)
{
    //如果产生了定时器中断
    switch( DL_TimerG_getPendingInterrupt(TIMER_0_INST) )
    {
        case DL_TIMER_IIDX_ZERO://如果是0溢出中断
					PID_SetSetpoint(&zhuanxiangPID1,30.0f); //设定PID控制器目标值
					speedyaw = PID_Compute(&zhuanxiangPID1,data6050err);
					PWM_speed1 = 400 - (int)speedyaw;
					PWM_speed2 = 400 + (int)speedyaw;
					if (PWM_speed1 > 999)  
										{  
												PWM_speed1 = 999;  
										}  
										else if (PWM_speed1 < 0)  
										{  
												PWM_speed1 = 0; // 确保不小于0  
										}  
										
										Motor_SetPWM0(PWM_speed1);  //左电机
										AIN1_OUT(1);  //前进
										AIN2_OUT(0);  

										if (PWM_speed2 > 999)  
										{  
												PWM_speed2 = 999;  
										}  
										else if (PWM_speed2 < 0)  
										{  
												PWM_speed2 = 0; // 确保不小于0  
										}  
										
										Motor_SetPWM1(PWM_speed2);  //右电机
										BIN1_OUT(1);   //前进
										BIN2_OUT(0);  
		
							
										
										
										
										
										
										
										
										
//							if(key_flag == 0)
//							{
//								Encoder_speed_1 = Encoder_speed1;
//								Encoder_speed_bias1 = Encoder_speed_1 - Encoder_speed_2 ;    //第一次获取编码器速度
//								Encoder_speed_2 = Encoder_speed_1;
//								Encoder_speed_bias3 = (float)((Encoder_speed_bias1+Encoder_speed_bias2)/2.0);//一次均值滤波
//								Encoder_speed_bias2 = Encoder_speed_bias1;
//								real_speed1 = (float)(((Encoder_speed_bias3/0.1)*0.2042/(13*45)*100));
//						
//								Encoder_speed_3 = Encoder_speed2;
//								Encoder_speed_bias4 = Encoder_speed_3 - Encoder_speed_4 ;    //第一次获取编码器速度
//								Encoder_speed_4 = Encoder_speed_3;
//								Encoder_speed_bias6 = (float)((Encoder_speed_bias4+Encoder_speed_bias5)/2.0);//一次均值滤波
//								Encoder_speed_bias5 = Encoder_speed_bias4;
//				
//								real_speed2 = (float)((Encoder_speed_bias6/0.1)*0.2042/(13*45)*100);
//						
//								//pid速度控制器
//								//真实速度由定时器测出 real_speed1 和 real_speed2
//								PID_SetSetpoint(&suduPID1,30.0f); //设定PID控制器目标值
//								speed1 = PID_Compute(&suduPID1,real_speed2);
//								PWM_speed1 += speed1;
//						
//								PID_SetSetpoint(&suduPID2,30.0f); //设定PID控制器目标值
//								speed2 = PID_Compute(&suduPID2,real_speed1);
//								PWM_speed2 += speed2;
//							
//								PID_SetSetpoint(&zhuanxiangPID1,0.0f); //设定PID控制器目标值
//								speedyaw = PID_Compute(&zhuanxiangPID1,data6050err);
//							
//								 // 将 data6050err 添加到 PWM_speed1 和 PWM_speed2  
//										
//										
//											PWM_speed1 -= (int)speedyaw;  
//											PWM_speed2 += (int)speedyaw;  
//										
//									
//										getback1 = ReadTCRT();
//								
//											if(getback1 != 0)
//										{
//											flag1=1;
//											AIN1_OUT(0);  
//											AIN2_OUT(0); 
//											BIN1_OUT(0);  
//											BIN2_OUT(0); 
//										}
//										 if(flag1 == 0)
//										{
//											// 确保PWM值在合法范围内  
//										if (PWM_speed1 > 999)  
//										{  
//												PWM_speed1 = 999;  
//										}  
//										else if (PWM_speed1 < 0)  
//										{  
//												PWM_speed1 = 0; // 确保不小于0  
//										}  
//										
//										Motor_SetPWM0(PWM_speed1);  //左电机
//										AIN1_OUT(1);  //前进
//										AIN2_OUT(0);  

//										if (PWM_speed2 > 999)  
//										{  
//												PWM_speed2 = 999;  
//										}  
//										else if (PWM_speed2 < 0)  
//										{  
//												PWM_speed2 = 0; // 确保不小于0  
//										}  
//										
//										Motor_SetPWM1(PWM_speed2);  //右电机
//										BIN1_OUT(1);   //前进
//										BIN2_OUT(0);  
//										
//										}
//										
//							}
//							
//							
//							
//							
//							
//							if(key_flag == 1)
//							{
//								//循迹
//								if(changeflag == 1)
//								{
//										
//										getback2 = ReadTCRT();
//									if(getback2 == 0 && data6050err <-150)
//									{
//										flag2 = 1;
//										
//										Motor_SetPWM0(400);
//										Motor_SetPWM1(400);
//											  AIN1_OUT(1);  
//												AIN2_OUT(0); 
//												BIN1_OUT(1);   
//												BIN2_OUT(0);  
//									
//										    
////										
//									}
//										else if(flag2 == 0)
//										{
//													if(getback2 == 3)
//												{
//													Motor_SetPWM0(200);   //左电机
//													Motor_SetPWM1(200);  //右电机
//												}
//												else if(getback2 == 1)
//												{
//													Motor_SetPWM0(200);
//													Motor_SetPWM1(400);
//												}
//												else if(getback2 == 2)
//												{
//													Motor_SetPWM0(200);
//													Motor_SetPWM1(350);
//												}
//												else if(getback2 == 4)
//												{
//													Motor_SetPWM0(350);
//													Motor_SetPWM1(200);
//												}
//												else if(getback2 == 5)
//												{
//													Motor_SetPWM0(400);
//													Motor_SetPWM1(200);
//												}
//												else if(getback2 == 6)
//												{
//													Motor_SetPWM0(200);
//													Motor_SetPWM1(450);
//												}
//												else if(getback2 == 7)
//												{
//													Motor_SetPWM0(450);
//													Motor_SetPWM1(200);
//												}
//												else if(getback2 == 8)
//												{
//													Motor_SetPWM0(200);
//													Motor_SetPWM1(325);
//												}
//												else if(getback2 == 9)
//												{
//													Motor_SetPWM0(325);
//													Motor_SetPWM1(200);
//												}
//												
//												AIN1_OUT(1);  //前进
//												AIN2_OUT(0); 
//												BIN1_OUT(1);   //前进
//												BIN2_OUT(0);  				
//										}
//										
//								}
//								
//								
//								//直线  速度环加转向环走直线
//								else if(changeflag == 0)
//								{
//								
//											PID_SetSetpoint(&zhuanxiangPID1,0.0f); //设定PID控制器目标值
//									    speedyaw = PID_Compute(&zhuanxiangPID1,data6050err);
//									
//									
//						
//									
//									Encoder_speed_1 = Encoder_speed1;
//									Encoder_speed_bias1 = Encoder_speed_1 - Encoder_speed_2 ;    //第一次获取编码器速度
//									Encoder_speed_2 = Encoder_speed_1;
//									Encoder_speed_bias3 = (float)((Encoder_speed_bias1+Encoder_speed_bias2)/2.0);//一次均值滤波
//									Encoder_speed_bias2 = Encoder_speed_bias1;
//									real_speed1 = (float)(((Encoder_speed_bias3/0.1)*0.2042/(13*45)*100));
//							
//									Encoder_speed_3 = Encoder_speed2;
//									Encoder_speed_bias4 = Encoder_speed_3 - Encoder_speed_4 ;    //第一次获取编码器速度
//									Encoder_speed_4 = Encoder_speed_3;
//									Encoder_speed_bias6 = (float)((Encoder_speed_bias4+Encoder_speed_bias5)/2.0);//一次均值滤波
//									Encoder_speed_bias5 = Encoder_speed_bias4;
//					
//									real_speed2 = (float)((Encoder_speed_bias6/0.1)*0.2042/(13*45)*100);
//							
//									//pid速度控制器
//									//真实速度由定时器测出 real_speed1 和 real_speed2
//									PID_SetSetpoint(&suduPID1,30.0f); //设定PID控制器目标值
//									speed1 = PID_Compute(&suduPID1,real_speed2);
//									PWM_speed1 += speed1;
//							
//									PID_SetSetpoint(&suduPID2,30.0f); //设定PID控制器目标值
//									speed2 = PID_Compute(&suduPID2,real_speed1);
//									PWM_speed2 += speed2;
//									
//					
//									 // 将 data6050err 添加到 PWM_speed1 和 PWM_speed2  
//											
//												PWM_speed1 -= (int)speedyaw;  
//												PWM_speed2 += (int)speedyaw;  
//											
//											getback1 = ReadTCRT();
//									
//												if(getback1 != 0) //识别到黑线
//											{
//												flag1=1;
//											
//												changeflag = 1;  //转变标志位，进入循迹
////												AIN1_OUT(0);  
////												AIN2_OUT(0); 
////												BIN1_OUT(0);  
////												BIN2_OUT(0); 
//											}
//											 if(flag1 == 0)
//											{
//												// 确保PWM值在合法范围内  
//											if (PWM_speed1 > 999)  
//											{  
//													PWM_speed1 = 999;  
//											}  
//											else if (PWM_speed1 < 0)  
//											{  
//													PWM_speed1 = 0; // 确保不小于0  
//											}  
//											
//											Motor_SetPWM0(PWM_speed1);  //左电机
//											AIN1_OUT(1);  //前进
//											AIN2_OUT(0);  

//											if (PWM_speed2 > 999)  
//											{  
//													PWM_speed2 = 999;  
//											}  
//											else if (PWM_speed2 < 0)  
//											{  
//													PWM_speed2 = 0; // 确保不小于0  
//											}  
//											
//											Motor_SetPWM1(PWM_speed2);  //右电机
//											BIN1_OUT(1);   //前进
//											BIN2_OUT(0);  
//											
//										}
//								}
//							
//							}
							
					
								
            break;
						
        default://其他的定时器中断
            break;
    }
}


