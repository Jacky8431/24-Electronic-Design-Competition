#ifndef __MY_TIMER_H
#define __MY_TIMER_H
#include "ti_msp_dl_config.h"
extern volatile float real_speed1 ;
extern volatile float real_speed2 ;

extern float yaw1;
extern float yawreal;

//PID����ֵ
extern float speed1;
extern float speed2;
extern float speedyaw;


extern float data6050err;

//PWMֵ
extern int PWM_speed1 ;
extern int PWM_speed2;
extern int PWM_zhuanxiangerr ;

void TIMER_0_INST_IRQHandler(void);

void TIMER_0_Init();

#endif