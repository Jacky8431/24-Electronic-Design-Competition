
#include "board.h"
#include <stdio.h>
#include "MPU6050.h"
#include "inv_mpu.h"
#include "my_timer.h"
#include  "Encoder.h"
#include "motor.h"
#include "PID.h"
#include "oled.h"
#include "TCRT.h"
#include "Key.h"

uint8_t status;


int main(void)
{
	board_init();
	

	
	Encoder_Init1();
	Encoder_Init2();

	//PID初始化
				PID_Init(&suduPID1,  1.0f, 0.0000f, 0.05f);   //初始化速度环PID控制器的参数
	      PID_Init(&suduPID2,  1.0f, 0.0000f, 0.05f);   //初始化速度环PID控制器的参数
				PID_Init(&zhuanxiangPID1,  2.0f, 0.0000f,3.0f);   //初始化转向环PID控制器的参数
			
	
		
   
		
			
    }
			
}

